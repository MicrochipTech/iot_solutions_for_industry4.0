// implemented interface(s)
#define D_Nv_Read D_Nv_Read_Impl
#define D_Nv_Write D_Nv_Write_Impl
#define D_Nv_EraseSector D_Nv_EraseSector_Impl
#define D_Nv_IsEmpty D_Nv_IsEmpty_Impl
#define D_Nv_IsEqual D_Nv_IsEqual_Impl

// no used interfaces
