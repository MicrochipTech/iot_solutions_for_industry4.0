// implemented interface(s)
#define D_XNv_Read D_XNv_Read_Impl
#define D_XNv_Write D_XNv_Write_Impl
#define D_XNv_EraseSector D_XNv_EraseSector_Impl
#define D_XNv_IsEmpty D_XNv_IsEmpty_Impl
#define D_XNv_IsEqual D_XNv_IsEqual_Impl

// no used interfaces
