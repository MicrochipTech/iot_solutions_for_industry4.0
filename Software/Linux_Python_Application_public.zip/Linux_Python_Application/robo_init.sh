wpa_supplicant -i wlan0 -D nl80211 -c /etc/wpa_supplicant.conf &
sleep 2
insmod /root/ewdemo/ch34x.ko
sleep 2
wpa_cli add_network 0
wpa_cli -p /var/run/wpa_supplicant ap_scan 1
wpa_cli set_network 0 ssid '"MCHPESELAB"'
wpa_cli set_network 0 key_mgmt WPA-PSK
wpa_cli set_network 0 psk '"CHALLENGER"'
wpa_cli select_network 0 &
sleep 5

udhcpc -i wlan0 &
export PATH=$PATH:/root

#iw phy0 interface add p2p0 type station
#sleep 2
#hostapd /etc/hostapd.conf -B &
#sleep 5
#ifconfig p2p0 192.168.0.1
#sleep 2
#/etc/init.d/S80dhcp-server start
#sleep 5
#python /root/iot_sam.py &
