import ntplib
import time
import subprocess
import cv2



ntp_server = ['pool.ntp.org',
              '0.de.pool.ntp.org'
              '1.de.pool.ntp.org',
              '2.de.pool.ntp.org',
              '3.de.pool.ntp.org',
              '0.europe.pool.ntp.org',
              '1.europe.pool.ntp.org',
              '2.europe.pool.ntp.org',
              '3.europe.pool.ntp.org',
              '0.uk.pool.ntp.org',
              '0.in.pool.ntp.org']

def get_ntp_time(time_server, update_system_time):
    g_time = None
    client = ntplib.NTPClient()
    for host in time_server:
        try:
            print 'Getting time from',host
            response = client.request(host, version=3)
            g_time = time.gmtime(response.tx_time)
            break
        except Exception as e:
            print "Failed to get time :",e
            pass
        
    if g_time:
        date_time = str(g_time.tm_year)+"-"+str(g_time.tm_mon)+"-"+str(g_time.tm_mday)+' '+str(g_time.tm_hour)+":"+str(g_time.tm_min)+":"+str(g_time.tm_sec)
        print date_time
        if update_system_time:
            cmd = 'date -s '+'"'+date_time+'"'
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
            p_status = p.wait()
    else:
        date_time = None
    return date_time

    
def enable_ap_mode():
    output = subprocess.check_output('iw phy0 interface add p2p0 type station', shell=True)
    print output
    time.sleep(2)
    output = subprocess.check_output('hostapd /etc/hostapd.conf -B &', shell=True)
    print output
    time.sleep(2)
    output = subprocess.check_output('ifconfig p2p0 192.168.0.1', shell=True)
    print output
    time.sleep(2)
    output = subprocess.check_output('/etc/init.d/S80dhcp-server start', shell=True)
    print output
    time.sleep(2)
    
    
